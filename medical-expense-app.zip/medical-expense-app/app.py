import streamlit as st
import joblib
import numpy as np

model = joblib.load("medical_expense_model.pkl")

st.title("Medical Expense Prediction App")

age = st.number_input("Age", 18, 100)
bmi = st.number_input("BMI", 10.0, 50.0)
children = st.number_input("Children", 0, 10)
smoker = st.selectbox("Smoker?", ["No", "Yes"])
region = st.selectbox("Region", ["northeast", "northwest", "southeast", "southwest"])

smoker_flag = 1 if smoker == "Yes" else 0
region_encoding = {
    "northeast": [0, 0, 0],   # base case (dropped)
    "northwest": [1, 0, 0],
    "southeast": [0, 1, 0],
    "southwest": [0, 0, 1],
}

region_vals = region_encoding[region]

features = np.array([[age, bmi, children, smoker_flag] + region_vals])

if st.button("Predict"):
    prediction = model.predict(features)[0]
    st.success(f"Predicted Medical Expense: ₹{prediction:,.2f}")
